from distutils.core import setup

setup(
    name='ops',
    version='0.1',
    packages=['ops']
)
